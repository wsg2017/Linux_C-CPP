gcc sync.c -o sync -I./ -L./hiredis -lhiredis
gcc async.c -o async -I./ -L./hiredis -lhiredis

