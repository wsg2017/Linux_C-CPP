redis连接池测试
